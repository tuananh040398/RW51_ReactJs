import React, { Component } from 'react'

export default class Count extends Component {
  render() {

    console.log(this.props)
    return (
      <div>
        <button onClick={()=>this.props.incre(1)}>Tăng</button>
        <button onClick={()=>this.props.decre(2)}>Giảm</button>
      </div>
    )
  }
}
