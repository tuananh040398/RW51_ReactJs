import React from 'react'

export default function TableHeader(props) {

  const {tableHeader} = props
  return (
    <>
        <thead>
            <tr>
            <th>{tableHeader.col3}</th>
            <th>{tableHeader.col1}</th>
            <th>{tableHeader.col2}</th>
            </tr>
        </thead>
    </>

      
  )
}
