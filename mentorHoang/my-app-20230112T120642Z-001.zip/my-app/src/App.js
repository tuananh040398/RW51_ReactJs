import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import Count from "./Count";
import Info from "./Info";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import ItemDetail from "./ItemDetail";
import FormItem from "./Form";
import TableExample from "./TableExam";
import { dataArr, DATA } from "./data";
class App extends React.Component {
  constructor() {
    super();
    this.state = {
      text: "",
      password: "",
      selected: "2",
      type1: true,
      type2: false,
      status: true,
      sex: 0,
      textParent: "Edit and save to reload.",
      result: 0,
      styleObj: {},
      arrInfo: dataArr,
      isRender: false,
      tableHeader: {
        col1: "fullname",
        col2: "age",
        col3: "id",
      },

      itemRenderUI: {},
    };
  }

  incre = (value) => {
    this.setState({
      result: value,
    });
  };

  decre = (value) => {
    this.setState({
      result: value,
    });
  };

  styleH1 = () => {
    this.setState({
      styleObj: {
        backgroundColor: "red",
        fontSize: "100px",
      },
    });
  };
  renderInfo = () => {
    return this.state.arrInfo.map((item, index) => {
      return <Info key={index} fullName={item.fullName} age={item.age} />;
    });
  };

  handleRender = () => {
    this.setState({
      isRender: true,
    });
  };
  getDetail = (id) => {
    let itemRender = this.state.arrInfo.filter((item) => item.id === id);
    this.setState({
      itemRenderUI: itemRender[0],
    });
  };

  changeInputValue = (e) => {
    let target = e.target;
    let name = target.name;
    let value = target.type === "checkbox" ? target.checked : e.target.value;
    this.setState({
      [name]: value,
    });
  };

  onSubmit = (e) => {
    e.preventDefault();
    console.log(this.state);
  };

  render() {
    const {
      text,
      result,
      styleObj,
      arrInfo,
      isRender,
      tableHeader,
      itemRenderUI,
      password,
      selected,
      type1,
      type2,
      sex,
    } = this.state;
    return (
      <div className="App">
        {/* <form onSubmit={this.onSubmit}>
          <input value={text} onChange={this.changeInputValue} name="text" />
          <input
            value={password}
            onChange={this.changeInputValue}
            name="password"
          />
          <div>
            <select
              onChange={this.changeInputValue}
              name="selected"
              value={selected}
            >
              <option value={1}>1</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
            </select>
          </div>

          <div>
            <input type="radio" name="sex" value={sex} /> Nam
            <input type="radio" name="sex" value={sex} /> Nu
          </div>

          <div>
            <input
              type="checkbox"
              name="type1"
              value={type1}
              defaultChecked={type1}
              onChange={this.changeInputValue}
            />{" "}
            Nam
            <input
              type="checkbox"
              name="type2"
              value={type2}
              onChange={this.changeInputValue}
            />{" "}
            Nu
          </div>

          <input type="submit" />
        </form> */}
        {/* <p>{text}</p> */}

        <Container>
          <FormItem />
          <br />
          <TableExample />
        </Container>
      </div>
    );
  }
}

export default App;
