export const dataArr = [
  { id: 1, fullName: "Name 1", age: 10 },
  { id: 2, fullName: "Name 2", age: 13 },
  { id: 3, fullName: "Name 3", age: 14 },
];

const arr2 = [
  { id: 1, fullName: "Name 1", age: 10 },
  { id: 2, fullName: "Name 2", age: 13 },
  { id: 3, fullName: "Name 3", age: 14 },
];

export default arr2;
