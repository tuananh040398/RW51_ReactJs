function text() {
  return (
    <div>
      <p>Demo</p>
      <input type="text" />
      <button>Click</button>
    </div>
  );
}

export default text;
